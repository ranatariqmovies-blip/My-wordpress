<?php /* Template Name: Services */ get_header();
aurele_hero('SERVICES','What We Do','Strategy, creativity and technology working together to accelerate growth.');?>
<section class="pg sub-page"><div class="wrap"><?php while(have_posts()){the_post();if(trim(get_the_content()))echo '<div class="entry">',apply_filters('the_content',get_the_content()),'</div>';}?>
<div class="sg" style="margin-top:0"><?php $i=0;foreach(aurele_services() as $k=>$s){$i++;?>
<a class="sv tilt rf u" style="transition-delay:<?php echo ($i%3)*.1;?>s" href="<?php echo esc_url(aurele_url($k));?>"><i class="bd"></i><span class="no">0<?php echo $i;?></span><span class="ar">Learn More →</span><div class="ic"><svg viewBox="0 0 24 24"><?php echo $s[2];?></svg></div><h3><?php echo esc_html($s[0]);?></h3><p><?php echo esc_html($s[1]);?></p></a>
<?php }?></div></div></section>
<?php aurele_cta();get_footer();
