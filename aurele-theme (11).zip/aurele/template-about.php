<?php /* Template Name: About Us */ get_header();
aurele_hero('ABOUT US',"We Don't Chase Trends. We Build What Works.",'A senior team of strategists, creators and analysts who plan, shoot, launch and measure every campaign together.');?>
<section class="pg"><div class="wrap two">
<div><h2 class="rf u">Our Story</h2></div>
<div class="rf u"><p class="t">Auréle started as three people and one belief: attention is only valuable when it turns into something. We left big agencies tired of reports that celebrated reach and ignored revenue.</p><p class="t">Today we work with a limited number of brands at a time, so every client gets senior people and honest answers. Nothing ships without a number it's meant to move.</p><?php while(have_posts()){the_post();the_content();}?></div></div></section>
<section class="pg"><div class="wrap"><h2 class="rf u">What We Believe</h2><div class="vcs">
<div class="vc rf u"><h3>Results first</h3><p>Every idea is tied to a goal we can measure.</p></div>
<div class="vc rf u" style="transition-delay:.1s"><h3>Craft matters</h3><p>Creative that earns attention and holds it.</p></div>
<div class="vc rf u" style="transition-delay:.2s"><h3>Straight talk</h3><p>Clear reporting and honest advice, including what to stop doing.</p></div></div></div></section>
<section class="pg"><div class="wrap"><div class="st">
<div class="rf u"><b>250+</b><span>Projects launched</span></div><div class="rf u"><b>40+</b><span>Brands transformed</span></div><div class="rf u"><b>3.8X</b><span>Average campaign growth</span></div><div class="rf u"><b>72%</b><span>Higher engagement</span></div></div></div></section>
<?php aurele_cta();get_footer();
