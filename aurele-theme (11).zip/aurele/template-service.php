<?php /* Template Name: Service Detail */ get_header();
$S=aurele_services();
while(have_posts()){the_post();$d=$S[get_post_field('post_name')]??null;$x=$d?$d[4]:null;$t=get_the_title();$lead=has_excerpt()?get_the_excerpt():($d?$d[1]:'');$cu=aurele_url('contact-us');?>
<header class="ph"><div class="bg"><div class="glow g1"></div><div class="glow g2"></div><div class="glow g4"></div></div><div class="wrap shg"><div>
<p class="eb pre">SERVICE</p><h1 class="pt" aria-label="<?php echo esc_attr($t);?>"><?php echo esc_html($t);?></h1>
<?php if($lead)echo '<p class="hp pre" style="animation-delay:.5s">',esc_html($lead),'</p>';?>
<div class="btns pre" style="animation-delay:.7s"><a class="btn pri mag" href="<?php echo esc_url($cu);?>">Get Started <span class="a">→</span></a><a class="btn sec mag" href="<?php echo esc_url(aurele_url('services'));?>">All Services</a></div></div>
<?php if($d){?><div class="sh-vis" aria-hidden="true"><i class="r"></i><i class="r r2"></i><div class="sh-core"><div class="ic"><svg viewBox="0 0 24 24"><?php echo $d[2];?></svg></div></div><?php foreach($x['kw'] as $i=>$k)echo '<span class="sh-chip k'.$i.'">',esc_html($k),'</span>';?></div><?php }?></div></header>
<?php if(!$d){?><section class="pg"><div class="wrap"><div class="entry"><?php the_content();?></div></div></section><?php aurele_cta();continue;}?>
<section class="pg"><div class="wrap two"><div><h2 class="rf u">About <?php echo esc_html($t);?></h2></div>
<div class="rf u"><?php if(trim(get_the_content()))the_content();else foreach($x['about'] as $p)echo '<p class="t">',esc_html($p),'</p>';?></div></div></section>
<section class="pg"><div class="wrap"><h2 class="rf u">What We Offer</h2><div class="vcs">
<?php foreach($x['offer'] as $i=>$o)echo '<article class="vc oc rf u" style="transition-delay:',($i%3)*.1,'s"><div class="ic"><svg viewBox="0 0 24 24">',aurele_ic($o[2]),'</svg></div><h3>',esc_html($o[0]),'</h3><p>',esc_html($o[1]),'</p></article>';?></div></div></section>
<section class="pg"><div class="wrap"><h2 class="rf u">Our Process</h2><div class="pst">
<?php foreach($x['process'] as $i=>$p)echo '<div class="rf u" style="transition-delay:',$i*.08,'s"><h3>',esc_html($p[0]),'</h3><p>',esc_html($p[1]),'</p></div>';?></div></div></section>
<section class="pg"><div class="wrap"><h2 class="rf u">Key Benefits</h2><div class="bn">
<?php foreach($x['benefits'] as $i=>$b)echo '<div class="rf u" style="transition-delay:',($i%2)*.1,'s"><h3>',esc_html($b[0]),'</h3><p>',esc_html($b[1]),'</p></div>';?></div></div></section>
<section class="pg"><div class="wrap"><h2 class="rf u">Why Choose Us</h2><p class="t rf u"><?php echo esc_html($x['why']);?></p><div class="wy">
<?php foreach(aurele_why() as $i=>$w)echo '<div class="rf u" style="transition-delay:',($i%3)*.08,'s"><div class="ic"><svg viewBox="0 0 24 24">',aurele_ic($w[2]),'</svg></div><h3>',esc_html($w[0]),'</h3><p>',esc_html($w[1]),'</p></div>';?></div></div></section>
<section class="pg"><div class="wrap"><h2 class="rf u">Frequently Asked Questions</h2><div class="fql">
<?php foreach($x['faq'] as $i=>$f)echo '<div class="fq rf u"><h3><button type="button" aria-expanded="false" aria-controls="fa',$i,'"><span>',esc_html($f[0]),'</span><i></i></button></h3><div class="fa" id="fa',$i,'" role="region"><div><p>',esc_html($f[1]),'</p></div></div></div>';?></div>
<div class="chips rf u"><?php foreach($S as $k=>$s)if($s[0]!==$t)echo '<a href="',esc_url(aurele_url($k)),'">',esc_html($s[0]),'</a>';?></div></div></section>
<script type="application/ld+json"><?php echo wp_json_encode(['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>array_map(function($f){return['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];},$x['faq'])]);?></script>
<?php aurele_cta('Ready To Grow With '.$t.'?','Tell us about your goals and we will suggest a clear next step.');}get_footer();
