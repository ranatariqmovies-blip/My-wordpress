<?php get_header(); ?>
<svg width="0" height="0" style="position:absolute"><defs>
<symbol id="yt" viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="4"/><path d="M10 9l5 3-5 3z"/></symbol>
<symbol id="ig" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r=".6"/></symbol>
<symbol id="tt" viewBox="0 0 24 24"><path d="M14 3v12.5a3.5 3.5 0 11-3.5-3.5M14 3c.4 2.6 2.1 4.4 5 4.6"/></symbol>
<symbol id="fb" viewBox="0 0 24 24"><path d="M14 8h3V4h-3a4 4 0 00-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8.5c0-.3.2-.5.5-.5z"/></symbol>
</defs></svg>
<header class="hero" id="home"><div class="bg"><div class="glow g1"></div><div class="glow g2"></div><div class="glow g3"></div><div class="glow g4"></div><canvas id="pt"></canvas></div>
<div class="wrap hg" id="hg"><div id="ht">
<p class="eb pre" style="animation-delay:.8s">YOUR GROWTH PARTNER</p>
<h1 id="h1" aria-label="Good Ideas Deserve Better Results."><span class="wd" aria-hidden="true" style="--i:0;--c:inset(0 0 100% 0);--t:translateY(30px);--f:blur(0)">Good</span> <span class="wd" aria-hidden="true" style="--i:1;--c:inset(100% 0 0 0);--t:translateY(80%);--f:blur(0)">Ideas</span><br><span class="wd gr" aria-hidden="true" style="--i:2;--c:inset(0 100% 0 0);--t:translateX(-90px);--f:blur(0)">Deserve</span><br><span class="wd" aria-hidden="true" style="--i:3;--c:inset(-20% -10% -20% -10%);--t:none;--f:blur(16px)">Better</span> <span class="wd" aria-hidden="true" style="--i:4;--c:inset(-20% -10% -20% -10%);--t:scale(.55);--f:blur(0)">Results.</span> </h1>
<p class="hs pre" style="animation-delay:1.3s">Let's Make Your Brand Hard to Ignore.</p>
<p class="hp pre" style="animation-delay:1.4s">We help businesses get noticed, attract the right people, and turn attention into real growth. From websites and digital marketing to YouTube management and business strategy, we bring the right people and ideas together to move your business forward.</p>
<div class="btns pre" style="animation-delay:1.55s"><a href="<?php echo esc_url(aurele_url('contact-us')); ?>" class="btn pri mag">Book a Free Call <span class="a">→</span></a><a href="#work" class="btn sec mag">See Our Work</a></div></div>
<div class="vis" id="vis">
<div class="layer" data-d="14"><svg class="net" viewBox="0 0 600 600"><defs><linearGradient id="lg" x1="0" x2="1"><stop offset="0" stop-color="#D6A85F" stop-opacity=".1"/><stop offset=".5" stop-color="#D6A85F"/><stop offset="1" stop-color="#5F2240"/></linearGradient></defs>
<circle class="ring rot" cx="300" cy="300" r="140"/><circle class="ring rot rot2" cx="300" cy="300" r="215"/><circle class="ring rot" cx="300" cy="300" r="285" style="opacity:.5"/>
<path class="ln2" d="M300 300L470 90"/><path class="ln2" d="M300 300L540 270"/><path class="ln2" d="M300 300L450 520"/><path class="ln2" d="M300 300L60 410"/>
<circle cx="470" cy="90" r="4" fill="#D6A85F"/><circle cx="540" cy="270" r="4" fill="#D6A85F"/><circle cx="450" cy="520" r="4" fill="#D6A85F"/><circle cx="60" cy="410" r="4" fill="#D6A85F"/></svg>
<div class="core"><svg viewBox="0 0 24 24"><path d="M4 17l6-6 4 4 6-8M15 7h5v5"/></svg></div></div>
<div class="layer" data-d="30"><div class="card c1 fl"><small>Website Traffic</small><b id="gn">+0%</b><svg class="gph" viewBox="0 0 200 70"><path id="gl" pathLength="300" d="M0 62C30 60 40 48 62 50S100 30 125 28S170 10 198 6"/><circle class="p" cx="62" cy="50" r="3" style="--t:2.85s"/><circle class="p" cx="125" cy="28" r="3" style="--t:3.6s"/><circle class="p e" cx="198" cy="6" r="4.5" style="--t:4.5s"/></svg></div>
<div class="card c2 fl" style="animation-delay:-3s"><small>More Qualified Leads</small><b class="gold" id="g2n">0%</b></div>
<div class="card c3 fl" style="animation-delay:-5s"><small>Return on Ad Spend</small><b id="g3n">0×</b></div></div>
<div class="layer" data-d="52"><svg class="net2" id="nw"></svg>
<a class="so yt" data-cur="YouTube" href="#" aria-label="YouTube"><svg><use href="#yt"/></svg><em>VIDEO</em></a>
<a class="so ig" data-cur="Instagram" href="#" aria-label="Instagram"><svg><use href="#ig"/></svg><em>SOCIAL</em></a>
<a class="so tt" data-cur="TikTok" href="#" aria-label="TikTok"><svg><use href="#tt"/></svg><em>VIRAL</em></a>
<a class="so fb" data-cur="Facebook" href="#" aria-label="Facebook"><svg><use href="#fb"/></svg><em>COMMUNITY</em></a></div>
</div></div></header>

<div class="trust"><h2 class="tt2 rf u">Good People. Great Partnerships.</h2><p class="ts2 rf u">We work with businesses and creators who are ready to take the next step.</p><div class="mq"><div class="tr" id="m1"></div></div></div>

<section id="services"><div class="pin"><div class="wrap"><h2 class="rf u">What We Do</h2><p class="sub rf u">Different businesses need different things. We help you find what works for yours, then turn that plan into action.</p>
</div><div class="sgw"><div class="sg" id="sg"></div></div><div class="wrap"><div class="sp"><i id="spi"></i></div></div></div></section>

<section class="why"><div class="vw" id="vw"></div><div class="wrap"><h2 class="rf z">Marketing Shouldn't Just Look Good. It Should Perform.</h2>
<div class="st"><div class="rf u"><b data-n="3.8" data-s="X" data-f="1">0</b><span>Average campaign growth</span></div><div class="rf u" style="transition-delay:.1s"><b data-n="72" data-s="%">0</b><span>Higher engagement</span></div><div class="rf u" style="transition-delay:.2s"><b data-n="250" data-s="+">0</b><span>Projects launched</span></div><div class="rf u" style="transition-delay:.3s"><b data-n="40" data-s="+">0</b><span>Brands transformed</span></div></div></div></section>

<section id="process"><div class="pin"><div class="wrap"><h2 class="rf u">How We Turn Ideas Into Growth</h2>
<div class="pr" id="pr"><div class="pl"><div class="pf" id="pf"></div></div></div></div></div></section>

<section id="work" style="padding-top:0"><div class="wrap"><h2 class="rf u">Work That Moves The Needle.</h2><div class="wg" id="wg"></div></div></section>

<div class="big"><div class="mq"><div class="tr" id="m2"></div></div></div>

<section id="about"><div class="wrap ab"><div><h2 id="ah"><span class="al">We Don't Chase</span><span class="al ac" id="tr">Trends.</span><span class="al">We Build What Works.</span></h2><div class="orb rf z"><i></i><i></i><i></i></div></div>
<div class="rv" id="rv"><p>Auréle started as three people and one belief: attention is only valuable when it turns into something. We left big agencies tired of reports that celebrated reach and ignored revenue.</p><p>Today we're a team of strategists, creators and analysts who plan, shoot, launch and measure every campaign together. Nothing ships without a number it's meant to move.</p><p>We work with a limited number of brands at a time, so every client gets senior people and honest answers.</p></div></div></section>

<section><div class="wrap"><h2 class="rf u">Kind Words From Brands We've Grown.</h2>
<div class="ts rf u"><div class="tk" id="tk">
<div class="tc"><div class="tq"><p>They rebuilt our social presence in one quarter. Followers became customers, and we can see it in the sales data.</p><cite><b>Maya Okafor</b> — Founder, Northfold Skincare</cite></div></div>
<div class="tc"><div class="tq"><p>Our paid media finally paid back. Auréle cut our acquisition cost nearly in half without dropping volume.</p><cite><b>Daniel Reyes</b> — CMO, Halden Outdoor</cite></div></div>
<div class="tc"><div class="tq"><p>The rebrand gave us a voice we're proud of. Three months later, inbound leads had doubled.</p><cite><b>Priya Nair</b> — Director, Lumen Wealth</cite></div></div>
<div class="tc"><div class="tq"><p>Honest, fast and creative. They told us what to stop doing, and that saved us more than any campaign.</p><cite><b>Tomás Vidal</b> — CEO, Casa Meridian</cite></div></div></div></div>
<div class="dots" id="dots"></div></div></section>

<section class="cta" id="contact"><div class="cg"></div><div class="cd" id="cd"></div><div class="wrap"><h2 class="rf z">Ready To Make Your Brand Impossible To Ignore?</h2><p class="rf u">Let's build something people remember.</p><a href="<?php echo esc_url(aurele_url('contact-us')); ?>" class="btn pri mag rf u">Start Your Project <span class="a">→</span></a></div></section>
<?php get_footer(); ?>
