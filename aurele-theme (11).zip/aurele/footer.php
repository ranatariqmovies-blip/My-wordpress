<footer class="foot"><div class="wrap"><div class="fg">
<div><a href="#home" class="logo">Auréle<i>.</i></a><p style="margin-top:14px;max-width:28ch">Digital marketing for brands that plan to be remembered.</p>
<div class="fs"><a href="#" aria-label="YouTube"><svg><use href="#yt"/></svg></a><a href="#" aria-label="Instagram"><svg><use href="#ig"/></svg></a><a href="#" aria-label="TikTok"><svg><use href="#tt"/></svg></a><a href="#" aria-label="Facebook"><svg><use href="#fb"/></svg></a></div></div>
<div><h4>EXPLORE</h4><ul><li><a class="l" href="<?php echo esc_url(aurele_home()); ?>">Home</a></li><li><a class="l" href="<?php echo esc_url(aurele_url('about-us')); ?>">About Us</a></li><li><a class="l" href="<?php echo esc_url(aurele_url('services')); ?>">Services</a></li><li><a class="l" href="<?php echo esc_url(home_url('/#work')); ?>">Work</a></li><li><a class="l" href="<?php echo esc_url(aurele_url('contact-us')); ?>">Contact Us</a></li></ul></div>
<div><h4>STUDIO</h4><ul><li>12 Gallery Row, Suite 4</li><li>London, UK</li></ul></div>
<div><h4>CONTACT</h4><ul><li><a class="l" href="mailto:<?php echo esc_attr(aurele_info('email')); ?>"><?php echo esc_html(aurele_info('email')); ?></a></li><li><?php echo esc_html(aurele_info('phone')); ?></li></ul></div></div>
<div class="wm" id="wm" aria-hidden="true"><span>G</span><span>R</span><span>O</span><span>W</span></div><div class="cp"><span>© 2026 Auréle Agency. All rights reserved.</span><span>Made with care.</span></div></div></footer>
<?php wp_footer(); ?>
</body>
</html>
