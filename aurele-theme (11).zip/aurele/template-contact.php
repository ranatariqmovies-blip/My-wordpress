<?php /* Template Name: Contact Us */ get_header();
aurele_hero('CONTACT US',"Let's Talk.",'Tell us about your project and we will reply within one working day.');?>
<section class="pg" id="form"><div class="wrap two"><div class="rf u">
<?php if(isset($_GET['sent']))echo '<div class="nt ok" role="status">Thank you. Your message has been sent and we will be in touch soon.</div>';if(isset($_GET['err']))echo '<div class="nt er" role="alert">Sorry, we could not send that. Please check your details and try again.</div>';?>
<form class="fm" method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>">
<input type="hidden" name="action" value="aurele_contact"><input class="hpt" type="text" name="hp_url" tabindex="-1" autocomplete="off" aria-hidden="true">
<label>Your name<input type="text" name="name" required></label>
<label>Email<input type="email" name="email" required></label>
<label>Phone (optional)<input type="tel" name="phone"></label>
<label>Service<select name="service"><option value="">Choose a service</option><?php foreach(aurele_services() as $s)echo '<option>',esc_html($s[0]),'</option>';?><option>Something else</option></select></label>
<label>Message<textarea name="message" required minlength="5"></textarea></label>
<button class="btn pri mag" type="submit">Send Message <span class="a">→</span></button></form></div>
<div class="info rf u"><div><small>EMAIL</small><a href="mailto:<?php echo esc_attr(aurele_info('email'));?>"><?php echo esc_html(aurele_info('email'));?></a></div><div><small>PHONE</small><?php echo esc_html(aurele_info('phone'));?></div><div><small>STUDIO</small><?php echo esc_html(aurele_info('address'));?></div>
<?php while(have_posts()){the_post();if(trim(get_the_content()))echo '<div>',apply_filters('the_content',get_the_content()),'</div>';}?></div></div></section>
<?php get_footer();
