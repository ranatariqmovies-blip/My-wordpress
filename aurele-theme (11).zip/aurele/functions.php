<?php
require get_template_directory().'/inc/services.php';
add_action('after_setup_theme',function(){add_theme_support('title-tag');add_post_type_support('page','excerpt');register_nav_menus(['primary'=>'Primary Menu (header + mobile)']);});
add_filter('body_class',function($c){return is_front_page()?$c:array_merge($c,['ready','subpage']);});
add_action('wp_enqueue_scripts',function(){
 $v=wp_get_theme()->get('Version');$u=get_template_directory_uri();
 wp_enqueue_style('aurele-fonts','https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,600;12..96,800&family=Manrope:wght@400;500;600&display=swap',[],null);
 wp_enqueue_style('aurele-main',$u.'/assets/css/main.css',[],$v);
 wp_enqueue_script('aurele-nav',$u.'/assets/js/nav.js',[],$v,true);
 if(is_front_page()){
  wp_enqueue_script('aurele-main',$u.'/assets/js/main.js',[],$v,true);
  wp_localize_script('aurele-main','aureleData',['services'=>array_map('aurele_url',array_keys(aurele_services())),'cards'=>array_fill(0,4,aurele_url('services'))]);
 }else{
  wp_enqueue_style('aurele-pages',$u.'/assets/css/pages.css',['aurele-main'],$v);
  wp_enqueue_script('aurele-pages',$u.'/assets/js/pages.js',[],$v,true);
 }
});
add_action('wp_head',function(){echo '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'."\n";},1);
// Ask search engines not to index or follow this site (remove these two lines when you are ready to go public).
add_filter('wp_robots','wp_robots_no_robots');
add_action('wp_head',function(){echo '<meta name="robots" content="noindex, nofollow">'."\n";},2);
/* ---------- helpers ---------- */
function aurele_info($k){$d=apply_filters('aurele_info',['email'=>'hello@aurele.agency','phone'=>'+44 20 7946 0123','address'=>'12 Gallery Row, Suite 4, London, UK']);return $d[$k]??'';}
function aurele_home(){return is_front_page()?'#home':home_url('/');}
function aurele_url($key){
 $m=get_option('aurele_pages',[]);if(!empty($m[$key])&&get_post_status($m[$key])==='publish')return get_permalink($m[$key]);
 $p=get_page_by_path($key)?:get_page_by_path('services/'.$key);return $p?get_permalink($p):home_url('/');}
function aurele_hero($eb,$t,$l=''){echo '<header class="ph"><div class="bg"><div class="glow g1"></div><div class="glow g2"></div><div class="glow g4"></div></div><div class="wrap"><p class="eb pre">'.esc_html($eb).'</p><h1 class="pt" aria-label="'.esc_attr($t).'">'.esc_html($t).'</h1>'.($l?'<p class="hp pre" style="animation-delay:.5s">'.esc_html($l).'</p>':'').'</div></header>';}
function aurele_cta($t='Ready To Make Your Brand Impossible To Ignore?',$p='Let\'s build something people remember.'){echo '<section class="cta"><div class="cg"></div><div class="wrap"><h2 class="rf u">'.esc_html($t).'</h2><p class="rf u">'.esc_html($p).'</p><a href="'.esc_url(aurele_url('contact-us')).'" class="btn pri mag rf u">Start Your Project <span class="a">→</span></a></div></section>';}
/* ---------- menu: reads the Primary Menu (with sub-items) and prints plain links, so the header design is unchanged ---------- */
function aurele_nav_items(){
 $loc=get_nav_menu_locations();
 if(!empty($loc['primary'])){$its=wp_get_nav_menu_items($loc['primary']);
  if($its){$by=[];foreach($its as $i)$by[(int)$i->menu_item_parent][]=$i;$out=[];
   foreach($by[0]??[] as $i){$ch=[];foreach($by[$i->ID]??[] as $c)$ch[]=[$c->title,$c->url,(int)$c->object_id];$out[]=[$i->title,$i->url,(int)$i->object_id,$ch];}
   return $out;}}
 $sv=[];foreach(aurele_services() as $k=>$s)$sv[]=[$s[0],aurele_url($k),0];
 return [['Home',home_url('/'),0,[]],['About Us',aurele_url('about-us'),0,[]],['Services',aurele_url('services'),0,$sv],['Contact Us',aurele_url('contact-us'),0,[]]];
}
function aurele_menu($mobile=false){
 $q=get_queried_object_id();
 $href=function($u){return (is_front_page()&&(untrailingslashit($u)===untrailingslashit(home_url())||$u==='/'))?'#home':$u;};
 $a=function($t,$u,$cur)use($href){return '<a href="'.esc_url($href($u)).'"'.($cur?' class="current" aria-current="page"':'').'>'.esc_html($t).'</a>';};
 foreach(aurele_nav_items() as $i){
  $cur=$i[2]&&$i[2]===$q;
  if(empty($i[3])){echo $a($i[0],$i[1],$cur);continue;}
  $subs='';foreach($i[3] as $c){$on=$c[2]&&$c[2]===$q;if($on)$cur=true;$subs.=$a($c[0],$c[1],$on);}
  $btn='<button type="button" class="cr" aria-expanded="false" aria-haspopup="true" aria-label="'.esc_attr('Toggle '.$i[0].' submenu').'"><svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2 4.5l4 4 4-4"/></svg></button>';
  $p=$a($i[0],$i[1],$cur);
  echo $mobile?'<div class="mi">'.$p.$btn.'<div class="sm2">'.$subs.'</div></div>':'<span class="hd"><span class="pa">'.$p.$btn.'</span><div class="dd"><div class="ddi">'.$subs.'</div></div></span>';
 }
}
/* ---------- setup: pages + menu. Safe to re-run: never duplicates pages or menu items, never overwrites content ---------- */
function aurele_setup(){
 if(get_option('aurele_setup')==='3'||!current_user_can('manage_options'))return;
 $map=get_option('aurele_pages',[]);
 $mk=function($key,$title,$tpl,$parent=0)use(&$map){
  $ex=get_page_by_path($parent?get_post_field('post_name',$parent).'/'.$key:$key);
  if($ex){$map[$key]=$ex->ID;return $ex->ID;}
  $id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>$title,'post_name'=>$key,'post_parent'=>$parent,'page_template'=>$tpl]);
  if(!is_wp_error($id))$map[$key]=$id;return $id;};
 $a=$mk('about-us','About Us','template-about.php');$s=$mk('services','Services','template-services.php');$c=$mk('contact-us','Contact Us','template-contact.php');
 foreach(aurele_services() as $k=>$v)$mk($k,$v[0],'template-service.php',$s);
 update_option('aurele_pages',$map);
 $loc=get_theme_mod('nav_menu_locations',[]);$mid=!empty($loc['primary'])?(int)$loc['primary']:0;
 if(!$mid||!wp_get_nav_menu_object($mid)){
  $m=wp_get_nav_menu_object('Aurele Primary');$mid=$m?$m->term_id:wp_create_nav_menu('Aurele Primary');
  if(is_wp_error($mid))$mid=0;else{$loc['primary']=$mid;set_theme_mod('nav_menu_locations',$loc);}}
 if($mid){
  $items=wp_get_nav_menu_items($mid)?:[];$fresh=!$items;
  $find=function($oid)use(&$items){foreach($items as $i)if($i->type==='post_type'&&(int)$i->object_id===(int)$oid)return $i;return null;};
  $add=function($t,$oid,$par=0)use($mid){return wp_update_nav_menu_item($mid,0,['menu-item-title'=>$t,'menu-item-object'=>'page','menu-item-object-id'=>$oid,'menu-item-type'=>'post_type','menu-item-status'=>'publish','menu-item-parent-id'=>$par]);};
  if($fresh)wp_update_nav_menu_item($mid,0,['menu-item-title'=>'Home','menu-item-url'=>home_url('/'),'menu-item-type'=>'custom','menu-item-status'=>'publish']);
  if($fresh&&$a&&!$find($a))$add('About Us',$a);
  if($s&&!$find($s))$add('Services',$s);
  if($fresh&&$c&&!$find($c))$add('Contact Us',$c);
  $items=wp_get_nav_menu_items($mid)?:[];$sit=$find($s);
  if($sit)foreach(aurele_services() as $k=>$v){$pid=$map[$k]??0;if($pid&&!$find($pid))$add($v[0],$pid,$sit->ID);}
 }
 update_option('aurele_setup','3');
}
add_action('init','aurele_setup',20);add_action('after_switch_theme','aurele_setup');
/* ---------- contact form: saved to the dashboard (Enquiries) and emailed ---------- */
add_action('init',function(){register_post_type('aurele_enquiry',['labels'=>['name'=>'Enquiries','singular_name'=>'Enquiry','menu_name'=>'Enquiries','all_items'=>'All Enquiries','edit_item'=>'View Enquiry'],'public'=>false,'show_ui'=>true,'menu_icon'=>'dashicons-email','menu_position'=>25,'supports'=>['title','editor'],'capability_type'=>'post','capabilities'=>['create_posts'=>'do_not_allow'],'map_meta_cap'=>true]);});
add_filter('manage_aurele_enquiry_posts_columns',function($c){return['cb'=>$c['cb'],'title'=>'Name / Service','em'=>'Email','ph'=>'Phone','date'=>'Received'];});
add_action('manage_aurele_enquiry_posts_custom_column',function($c,$id){if($c==='em')echo esc_html(get_post_meta($id,'email',true));if($c==='ph')echo esc_html(get_post_meta($id,'phone',true));},10,2);
add_action('admin_post_nopriv_aurele_contact','aurele_contact');add_action('admin_post_aurele_contact','aurele_contact');
function aurele_contact(){
 $back=remove_query_arg(['sent','err'],wp_get_referer()?:aurele_url('contact-us'));
 $go=function($k)use($back){wp_safe_redirect(add_query_arg($k,'1',$back).'#form');exit;};
 $g=function($k){return wp_unslash($_POST[$k]??'');};
 if(!empty($_POST['hp_url']))$go('sent'); // bots: pretend success, store nothing
 $n=sanitize_text_field($g('name'));$e=sanitize_email($g('email'));$ph=sanitize_text_field($g('phone'));$sv=sanitize_text_field($g('service'));$m=sanitize_textarea_field($g('message'));
 if(!$n||!is_email($e)||strlen($m)<5)$go('err');
 $ip=md5($_SERVER['REMOTE_ADDR']??'x');$cnt=(int)get_transient('aur_rl_'.$ip);if($cnt>=8)$go('err');set_transient('aur_rl_'.$ip,$cnt+1,HOUR_IN_SECONDS);
 $body="Name: $n\nEmail: $e\nPhone: $ph\nService: $sv\n\n$m";
 $id=wp_insert_post(['post_type'=>'aurele_enquiry','post_status'=>'publish','post_title'=>$n.($sv?' — '.$sv:''),'post_content'=>$body,'meta_input'=>['email'=>$e,'phone'=>$ph,'service'=>$sv]]);
 if(is_wp_error($id)||!$id)$go('err');
 wp_mail(get_option('admin_email'),'New enquiry from '.$n,$body,['Reply-To: '.$n.' <'.$e.'>']); // email is best-effort; the enquiry is already saved
 $go('sent');
}
