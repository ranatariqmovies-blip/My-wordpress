<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<?php wp_head(); ?>
<noscript><style>.rf{opacity:1!important;transform:none!important;filter:none!important}#ld{display:none}.fq .fa{grid-template-rows:1fr!important}</style></noscript>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php if(is_front_page()): ?><div id="ld"><div class="lh t"></div><div class="lh b"></div><div class="lc"><div class="lg">Auréle<i>.</i></div><div class="lp" id="lp">00%</div></div></div><?php endif; ?>
<div id="fg"></div><div id="cur"></div>
<nav id="nav"><div class="wrap nb"><a href="<?php echo esc_url(aurele_home()); ?>" class="logo">Auréle<i>.</i></a>
<div class="links" id="lk"><i class="ulb"></i><?php aurele_menu(); ?></div>
<a href="<?php echo esc_url(aurele_url('contact-us')); ?>" class="btn cta-n mag">Let's Talk</a>
<button class="burger" id="bg" aria-label="Open menu" aria-expanded="false"><i></i><i></i></button></div></nav>
<div class="menu" id="menu"><?php aurele_menu(true); ?></div>
