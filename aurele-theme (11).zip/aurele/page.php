<?php get_header();while(have_posts()){the_post();aurele_hero('',get_the_title());?>
<section class="pg"><div class="wrap"><div class="entry"><?php the_content();?></div></div></section><?php }get_footer();
