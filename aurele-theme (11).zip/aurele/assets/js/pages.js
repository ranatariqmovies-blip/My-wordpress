(function(){
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches,FINE=matchMedia('(hover:hover) and (pointer:fine)').matches;
const nav=$('#nav');let ly=scrollY,dr=1;
addEventListener('scroll',()=>{const y=scrollY;nav.classList.toggle('s',y>40);if(Math.abs(y-ly)>4){dr=y>ly?1:-1;ly=y}nav.classList.toggle('sm',dr>0&&y>200)},{passive:true});
[$('.logo'),...$$('.links a'),$('.cta-n'),$('.burger')].forEach((e,i)=>e&&e.style.setProperty('--k',i));
const lk=$('#lk'),ub=lk.querySelector('.ulb');$$('#lk>a,#lk .pa>a').forEach(a=>a.addEventListener('mouseenter',()=>{ub.style.opacity=1;ub.style.width=a.offsetWidth+'px';ub.style.transform=`translateX(${a.offsetLeft}px)`}));lk.addEventListener('mouseleave',()=>ub.style.opacity=0);
const bg=$('#bg'),menu=$('#menu');function tm(o){bg.classList.toggle('o',o);menu.classList.toggle('o',o);bg.setAttribute('aria-expanded',o);document.body.style.overflow=o?'hidden':''}
bg.onclick=()=>tm(!menu.classList.contains('o'));$$('#menu a').forEach(a=>a.onclick=()=>tm(false));
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12});
$$('.pt').forEach(h=>{h.innerHTML=h.textContent.trim().split(' ').map((w,k)=>`<span class="sw" aria-hidden="true"><span class="si" style="--i:${k}">${w}</span></span> `).join('');h.dataset.m='m'});
$$('.rf,.pt').forEach(e=>io.observe(e));
setTimeout(()=>$$('.rf:not(.in),.pt:not(.in)').forEach(e=>{if(e.getBoundingClientRect().top<innerHeight)e.classList.add('in')}),1200);
$$('.sv').forEach(c=>c.addEventListener('mousemove',e=>{const r=c.getBoundingClientRect();c.style.setProperty('--mx',e.clientX-r.left+'px');c.style.setProperty('--my',e.clientY-r.top+'px')}));
const fg=$('#fg'),wl=[...($('#wm')||{children:[]}).children],ft=$('.foot');
(function f(){const y=scrollY,v=innerHeight;fg.style.transform=`translate(${Math.sin(y/900)*28}vw,${Math.cos(y/1400)*14}vh)`;
if(ft&&!RM){const r=ft.getBoundingClientRect(),p=clamp((v-r.top)/(r.height+40));wl.forEach((l,i)=>l.style.transform=`translateX(${(1.5-i)*(1-p)*.9}em)`)}requestAnimationFrame(f)})();
if(FINE&&!RM){
$$('.mag').forEach(el=>{el.addEventListener('mousemove',e=>{const r=el.getBoundingClientRect();el.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.28}px,${(e.clientY-r.top-r.height/2)*.28}px)`});el.addEventListener('mouseleave',()=>{el.style.transform=''})});
$$('.tilt').forEach(c=>{c.addEventListener('mousemove',e=>{const r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transition='border-color .4s,box-shadow .5s';c.style.transform=`perspective(900px) translateY(-8px) rotateX(${-y*5}deg) rotateY(${x*6}deg)`});c.addEventListener('mouseleave',()=>{c.style.transition='';c.style.transform=''})});
const cu=$('#cur');let cx=0,cy=0,tx=0,ty=0;addEventListener('mousemove',e=>{tx=e.clientX;ty=e.clientY;cu.style.opacity=1});
(function c(){cx+=(tx-cx)*.18;cy+=(ty-cy)*.18;cu.style.transform=`translate(${cx}px,${cy}px)`;requestAnimationFrame(c)})();
document.addEventListener('mouseover',e=>{const t=e.target.closest('[data-cur]');cu.textContent=t?t.dataset.cur:'';cu.classList.toggle('v',!!t);cu.classList.toggle('h',!!e.target.closest('a,button'))});
let cur=scrollY,tg=scrollY,own=0;const mx=()=>document.documentElement.scrollHeight-innerHeight;
addEventListener('wheel',e=>{if(e.ctrlKey||document.body.style.overflow=='hidden')return;e.preventDefault();tg=clamp(tg+e.deltaY*(e.deltaMode?30:1),0,mx())},{passive:false});
addEventListener('scroll',()=>{if(!own&&Math.abs(scrollY-cur)>3)cur=tg=scrollY});
(function f(){const d=tg-cur;if(Math.abs(d)>.3){own=1;cur+=d*.085;scrollTo(0,cur);setTimeout(()=>own=0,30)}requestAnimationFrame(f)})()}
$$('.fq').forEach(q=>{const b=q.querySelector('button');b.addEventListener('click',()=>{const o=q.classList.toggle('o');b.setAttribute('aria-expanded',o)})});
})();
