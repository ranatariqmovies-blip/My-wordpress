(function(){const $$=s=>[...document.querySelectorAll(s)];
function close(x){$$('.hd.o,.mi.o').forEach(h=>{if(h!==x){h.classList.remove('o');const b=h.querySelector('.cr');b&&b.setAttribute('aria-expanded','false')}})}
$$('.hd,.mi').forEach(h=>{const b=h.querySelector('.cr'),dd=h.querySelector('.dd'),pa=h.querySelector('.pa');
const pos=()=>{if(dd&&pa)dd.style.left=Math.max(0,pa.offsetLeft-24)+'px'};pos();addEventListener('resize',pos);
if(pa){pa.addEventListener('mouseenter',pos);h.addEventListener('mouseenter',()=>{pos();b.setAttribute('aria-expanded','true')});h.addEventListener('mouseleave',()=>b.setAttribute('aria-expanded',h.classList.contains('o')))}
b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const o=!h.classList.contains('o');close(h);h.classList.toggle('o',o);b.setAttribute('aria-expanded',o)});
h.addEventListener('keydown',e=>{if(e.key==='Escape'){close();b.focus()}})});
document.addEventListener('click',e=>{if(!e.target.closest('.hd,.mi'))close()});
})();
