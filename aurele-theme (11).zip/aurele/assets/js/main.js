(function(){

const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches,FINE=matchMedia('(hover:hover) and (pointer:fine)').matches,MOB=innerWidth<700;
const I=(p)=>`<svg viewBox="0 0 24 24">${p}</svg>`;
// marquees
const cl=['Northfold','HALDEN','Lumen & Co','Casa Meridian','Voltra','Aster Labs','Quillon','MAREA','Ironbark','Sable Studio'];
$('#m1').innerHTML=(cl.map(c=>`<span>${c}</span>`).join('')).repeat(2);
const bw=['Strategy','Content','Performance','Growth','Branding','Social','Digital'];
$('#m2').innerHTML=(bw.map((w,i)=>`<span class="${i%2?'':'f'}">${w}<b> ✦ </b></span>`).join('')).repeat(2);
// services
const sv=[['Digital Marketing',0,'More than clicks and likes. We help you reach the right audience, bring in better leads, and give people a reason to choose your business.','SEO · Local SEO · Meta Ads · Social Media · Content · Web Design'],
['YouTube Channel Management',0,'You bring the vision. We handle the work behind the videos, from finding topics people want to watch to writing scripts, improving titles, and managing uploads.','Research · Scripts · SEO · Thumbnails · Uploads · Channel Strategy'],
['Business Consultancy',0,'Not sure what to fix first or where to invest? We help you see the bigger picture, spot missed opportunities, and make decisions with more confidence.','Growth Planning · Business Strategy · Market Positioning · Process Improvement'],
['Product Research & Development',0,'Before you spend money building something new, make sure people actually want it. We research your market, study competitors, and help shape ideas around real customer needs.','Market Research · Competitor Analysis · Customer Insights · Product Planning']];
const IC=['<circle class="a" cx="12" cy="12" r="2"/><circle cx="5" cy="6" r="1.6"/><circle cx="19" cy="6" r="1.6"/><circle cx="12" cy="20" r="1.6"/><path class="d" d="M12 12L5 6M12 12l7-6M12 12v8"/>','<rect x="3" y="6" width="18" height="12" rx="3.5"/><path class="pp" d="M10 9.5l5 2.5-5 2.5z"/>','<circle cx="12" cy="12" r="8.5"/><path class="nd" d="M15.5 8.5l-2 5-5 2 2-5z"/>','<path d="M9 3h6M10 3v6l-5 9a2 2 0 001.8 3h10.4A2 2 0 0019 18l-5-9V3"/><circle class="bb" cx="10.5" cy="16.5" r="1"/><circle class="bb" cx="14" cy="17" r="1"/>'];$('#sg').innerHTML=sv.map((s,i)=>`<a class="sv tilt" href="${(window.aureleData&&aureleData.cards[i])||'#'}"><i class="bd"></i><span class="no">0${i+1}</span><span class="ar">Learn More →</span><div class="ic">${I(IC[i])}</div><h3>${s[0]}</h3><p>${s[2]}<span class="tg">${s[3]}</span></p></a>`).join('');
// process
const ps=[['Discover','We study your market, audience and numbers.'],['Strategize','One clear plan with goals, channels and budget.'],['Create','Content and creative built to stop the scroll.'],['Launch','Campaigns go live across the right platforms.'],['Optimize','We test weekly and move spend to what works.'],['Scale','Winning ideas grow into bigger, steadier results.']];
$('#pr').insertAdjacentHTML('beforeend',ps.map((p,i)=>`<div class="ps"><span class="n">0${i+1}</span><h3>${p[0]}</h3><p>${p[1]}</p></div>`).join(''));
// work
const wk=[['Social Growth Campaign','Northfold Skincare','Followers up 4× in six months, with a 31% lift in direct sales.','<circle cx="50" cy="50" r="38"/><circle cx="50" cy="50" r="24"/><circle cx="50" cy="50" r="10"/>'],
['E-Commerce Performance','Halden Outdoor','Cut acquisition cost by 46% while revenue grew 2.4×.','<path d="M8 80L30 55 48 66 70 30 92 12"/><path d="M8 92h84"/>'],
['Brand Transformation','Lumen Wealth','New identity, voice and site. Inbound leads doubled in 90 days.','<rect x="18" y="18" width="64" height="64" rx="10"/><path d="M18 50h64M50 18v64"/>'],
['Paid Media Growth','Casa Meridian','Multi-platform paid strategy that delivered 5.1× return on spend.','<path d="M10 70L50 20 90 70z"/><path d="M30 70l20-26 20 26"/>']];
const M=[['+184%','Social reach','+72%','Engagement','3.4X','ROAS'],['+146%','Revenue','−46%','Cost per sale','2.4X','ROAS'],['+112%','Inbound leads','+64%','Brand recall','2X','Pipeline'],['+93%','Conversions','+58%','Click-through','5.1X','ROAS']].map(m=>`<div class="mt">${[0,2,4].map((j,k)=>`<span style="--k:${k}"><b>${m[j]}</b>${m[j+1]}</span>`).join('')}</div>`);$('#wg').innerHTML=wk.map((w,i)=>`<a href="#" class="wk w${i+1} tilt mk" data-cur="EXPLORE"><div class="wv"><svg viewBox="0 0 100 100">${w[3]}</svg></div><div class="wo"></div><span class="ar">→</span><div class="wi"><small>Project 0${i+1} · ${w[1]}</small><h3>${w[0]}</h3><p>${w[2]}</p>${M[i]}</div></a>`).join('');
// nav
const nav=$('#nav');addEventListener('scroll',()=>nav.classList.toggle('s',scrollY>40),{passive:true});
const bg=$('#bg'),menu=$('#menu');
function tm(o){bg.classList.toggle('o',o);menu.classList.toggle('o',o);bg.setAttribute('aria-expanded',o);document.body.style.overflow=o?'hidden':''}
bg.onclick=()=>tm(!menu.classList.contains('o'));$$('#menu a').forEach(a=>a.onclick=()=>tm(false));
// reveal
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15});
$$('.rf').forEach(e=>io.observe(e));
// counters
const co=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;co.unobserve(e.target);const el=e.target,n=+el.dataset.n,f=el.dataset.f?1:0,s=el.dataset.s,t0=performance.now();
(function k(t){const p=Math.min((t-t0)/1800,1),v=n*(1-Math.pow(1-p,4));el.textContent=v.toFixed(f)+s;el.style.filter=`blur(${(1-p)*7}px)`;if(p<1&&!RM)requestAnimationFrame(k);else{el.textContent=n.toFixed(f)+s;el.style.filter='';el.animate([{scale:1.15},{scale:1}],{duration:600,easing:'cubic-bezier(.2,.8,.2,1)'})}})(t0)}),{threshold:.6});
$$('[data-n]').forEach(e=>co.observe(e));
// process scroll
const prE=$('#pr'),pf=$('#pf'),pss=$$('.ps');
function pp(){if(document.getElementById('process').classList.contains('pn'))return;const r=prE.getBoundingClientRect(),vh=innerHeight,p=Math.max(0,Math.min(1,(vh*.6-r.top)/r.height));pf.style.height=p*100+'%';
pss.forEach(s=>{const b=s.getBoundingClientRect();s.classList.toggle('on',b.top<vh*.62)})}
// about line reveal
const rv=$$('#rv p');rv.forEach(p=>{p.innerHTML=p.textContent.split(' ').map(w=>`<span class="w">${w}</span> `).join('')});
const ws=$$('.rv .w');
function ar(){const t=innerHeight*.78;ws.forEach(w=>w.classList.toggle('on',w.getBoundingClientRect().top<t))}
// big marquee driven by scroll
const m2=$('#m2');let lx=0,ly=scrollY,dir=1;
function tick(){lx+=(RM?0:(.7+(window.__v||0)*.6)*(window.__h?.3:1))*dir;const w=m2.scrollWidth/2;if(lx>w)lx-=w;if(lx<0)lx+=w;m2.style.transform=`translateX(${-lx}px)`;requestAnimationFrame(tick)}tick();
addEventListener('scroll',()=>{const y=scrollY;dir=y>=ly?1:-1;ly=y;pp();ar()},{passive:true});pp();ar();
// hero parallax
const vis=$('#vis'),ls=$$('#vis .layer');
if(FINE&&!RM){addEventListener('mousemove',e=>{const x=e.clientX/innerWidth-.5,y=e.clientY/innerHeight-.5;ls.forEach(l=>{const d=+l.dataset.d;l.style.transform=`translate(${-x*d}px,${-y*d}px)`})},{passive:true});
// magnetic
$$('.mag').forEach(el=>{el.addEventListener('mousemove',e=>{const r=el.getBoundingClientRect();el.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.28}px,${(e.clientY-r.top-r.height/2)*.28}px)`});el.addEventListener('mouseleave',()=>{el.style.transition='transform .5s cubic-bezier(.2,.8,.2,1),box-shadow .4s,background .4s,border-color .4s';el.style.transform='';setTimeout(()=>el.style.transition='',500)})});
// tilt
$$('.tilt').forEach(c=>{c.addEventListener('mousemove',e=>{const r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transition='border-color .4s,box-shadow .5s';c.style.transform=`perspective(900px) translateY(-8px) rotateX(${-y*5}deg) rotateY(${x*6}deg)`});c.addEventListener('mouseleave',()=>{c.style.transition='';c.style.transform=''})});
// cursor
const cu=$('#cur');let cx=0,cy=0,tx=0,ty=0;addEventListener('mousemove',e=>{tx=e.clientX;ty=e.clientY;cu.style.opacity=1});
(function c(){cx+=(tx-cx)*.18;cy+=(ty-cy)*.18;cu.style.transform=`translate(${cx}px,${cy}px)`;requestAnimationFrame(c)})();
$$('a,button').forEach(a=>{a.addEventListener('mouseenter',()=>cu.classList.add('h'));a.addEventListener('mouseleave',()=>cu.classList.remove('h'))})}

;
(function(){
const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v)),V=()=>innerHeight;
const nav=$('#nav'),hg=$('#hg'),ht=$('#ht'),vis=$('#vis'),c1=$('.c1'),gs=$$('.glow'),fgl=$('#fg');
// ---- split headings ----
const io2=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io2.unobserve(e.target)}}),{threshold:.3});
const modes=['m','b','l','m','b','m'];
$$('h2:not(#ah):not(.tt2)').forEach((h,i)=>{const m=modes[i]||'m';h.classList.remove('rf','u','z','l','r');h.setAttribute('aria-label',h.textContent);
h.innerHTML=h.textContent.trim().split(' ').map((w,k)=>`<span class="sw" aria-hidden="true"><span class="si" style="--i:${k}">${m=='l'?[...w].map((c,j)=>`<span style="--j:${j}">${c}</span>`).join(''):w}</span></span> `).join('');h.dataset.m=m;io2.observe(h)});
$$('.mk').forEach(e=>io.observe(e));
$$('.wk').forEach(e=>{const ar=e.querySelector('.ar');e.addEventListener('mousemove',ev=>{const r=e.getBoundingClientRect();ar.style.translate=`${clamp((ev.clientX-r.right+50)*.25,-60,10)}px ${clamp((ev.clientY-r.top-50)*.25,-10,60)}px`});e.addEventListener('mouseleave',()=>ar.style.translate='')});
$('#tk').dataset.cur='DRAG';
$$('.sv').forEach(c=>c.addEventListener('mousemove',e=>{const r=c.getBoundingClientRect();c.style.setProperty('--mx',e.clientX-r.left+'px');c.style.setProperty('--my',e.clientY-r.top+'px')}));
// ---- stat decor ----
const pp9=[...Array(9)].map((_,k)=>{const a=k*.7;return`<circle class="pp" r="2" cx="${55+Math.cos(a)*26}" cy="${40+Math.sin(a)*26}" style="--x:${Math.cos(a)*60}px;--y:${Math.sin(a)*60}px"/>`}).join('');
const DC=['<path class="g" pathLength="1" d="M2 72L25 56 45 62 70 32 106 8"/>','<circle cx="55" cy="40" r="30" stroke-opacity=".18"/><circle class="g r" pathLength="1" cx="55" cy="40" r="30" transform="rotate(-90 55 40)"/>',pp9,'<path class="g" pathLength="1" d="M10 62L40 20 70 54 100 14M40 20L58 74"/>'+[[10,62],[40,20],[70,54],[100,14],[58,74]].map((p,k)=>`<circle class="nd" style="--k:${k}" r="3" cx="${p[0]}" cy="${p[1]}"/>`).join('')];
$$('.st>div').forEach((d,i)=>d.insertAdjacentHTML('afterbegin',`<svg class="dc" viewBox="0 0 110 80">${DC[i]}</svg>`));
// ---- misc DOM ----
$$('#process .pl').forEach(l=>[0,1.1,2.2].forEach(d=>l.insertAdjacentHTML('beforeend',`<i class="tp" style="--d:${d}s"></i>`)));
[$('.logo'),...$$('.links a'),$('.cta-n'),$('.burger')].forEach((e,i)=>e.style.setProperty('--k',i));
const vw=$('#vw');vw.innerHTML='<span>GROW CREATE SCALE PERFORM </span>';vw.innerHTML+=vw.innerHTML;
const cd=$('#cd');cd.innerHTML='<span></span>'.repeat(MOB?10:18);const cds=[...cd.children];
// nav underline follows cursor
const lk=$('#lk'),ub=lk.querySelector('.ulb');$$('#lk>a,#lk .pa>a').forEach(a=>a.addEventListener('mouseenter',()=>{ub.style.opacity=1;ub.style.width=a.offsetWidth+'px';ub.style.transform=`translateX(${a.offsetLeft}px)`}));lk.addEventListener('mouseleave',()=>ub.style.opacity=0);
// cursor labels
if(FINE){const cu=$('#cur');document.addEventListener('mouseover',e=>{const t=e.target.closest&&e.target.closest('[data-cur]');cu.textContent=t?t.dataset.cur:'';cu.classList.toggle('v',!!t)})}
$('.big .mq').addEventListener('mouseenter',()=>window.__h=1);$('.big .mq').addEventListener('mouseleave',()=>window.__h=0);
// ---- testimonial stack ----
(function(){const cs=$$('.tc');let ord=cs.map((_,i)=>i),dx=0,drag=0,sx=0;const S=cs.map(()=>({x:0,y:0,r:0,s:1,v:[0,0,0,0]}));
const T=k=>k?{x:k*26,y:-k*12,r:k*1.8,s:1-k*.045}:{x:dx,y:0,r:dx*.035,s:1};
cs.forEach((c,i)=>c.addEventListener('pointerdown',e=>{if(ord[0]!=i)return;drag=1;sx=e.clientX;c.setPointerCapture(e.pointerId);c.style.cursor='grabbing'}));
addEventListener('pointermove',e=>{if(drag)dx=e.clientX-sx});
addEventListener('pointerup',()=>{if(!drag)return;drag=0;if(Math.abs(dx)>90)ord.push(ord.shift());dx=0;cs.forEach(c=>c.style.cursor='')});
(function f(){cs.forEach((c,i)=>{const k=ord.indexOf(i),t=T(k),s=S[i];['x','y','r','s'].forEach((p,j)=>{s.v[j]=(s.v[j]+(t[p]-s[p])*.12)*.76;s[p]+=s.v[j]});
c.style.transform=`translate3d(${s.x}px,${s.y}px,0) rotate(${s.r}deg) scale(${s.s})`;c.style.zIndex=9-k;c.style.opacity=k>3?0:1-k*.14});requestAnimationFrame(f)})()})();
// ---- hero social network ----
const so=$$('.so'),nw=$('#nw'),SV='http://www.w3.org/2000/svg';
const mk=(n,a)=>{const e=document.createElementNS(SV,n);for(const k in a)e.setAttribute(k,a[k]);nw.appendChild(e);return e};
const LN=[...Array(8)].map(()=>mk('line',{stroke:'#D6A85F','stroke-width':1}));
const PT=[...Array(12)].map((_,k)=>({c:mk('circle',{r:2.2,fill:'#D6A85F',opacity:0}),u:Math.random(),k:k%4}));
let B=[],hv=[0,0,0,0],hh=[0,0,0,0],mxp=0,myp=0,tmx=0,tmy=0,mx=0,my=0;
so.forEach((e,i)=>{e.addEventListener('mouseenter',()=>hh[i]=1);e.addEventListener('mouseleave',()=>hh[i]=0)});
addEventListener('pointermove',e=>{mxp=e.clientX;myp=e.clientY;tmx=e.clientX/innerWidth-.5;tmy=e.clientY/innerHeight-.5;window.__mx=tmx;window.__my=tmy});
const calc=()=>{B=so.map(e=>[e.offsetLeft+e.offsetWidth/2,e.offsetTop+e.offsetHeight/2])};
const setL=(l,a,b,o)=>{l.setAttribute('x1',a[0]);l.setAttribute('y1',a[1]);l.setAttribute('x2',b[0]);l.setAttribute('y2',b[1]);l.setAttribute('stroke-opacity',o)};
function orbit(t,p){if(!B.length)return;const R=vis.getBoundingClientRect(),cx=vis.offsetWidth/2,cy=vis.offsetHeight/2,C=[];
const O=[[Math.cos(t*.5)*22,Math.sin(t*.5)*22,0],[Math.sin(t*.7)*16,Math.sin(t*.7)*16,0],[0,Math.sin(t*.9)*14,Math.sin(t*.9)*10],[Math.cos(t*.4+2)*22,Math.sin(t*.4+2)*14,0]];
so.forEach((e,i)=>{hv[i]+=(hh[i]-hv[i])*.12;let[x,y,r]=O[i];const[bx,by]=B[i],dx=bx-cx,dy=by-cy,dl=Math.hypot(dx,dy)||1;
x+=(mxp-R.left-bx-x)*.22*hv[i]+dx/dl*p*150;y+=(myp-R.top-by-y)*.22*hv[i]+dy/dl*p*150;
e.style.transform=`translate3d(${x}px,${y}px,0) rotate(${r}deg) scale(${1+.35*hv[i]})`;C[i]=[bx+x,by+y]});
for(let i=0;i<4;i++){const j=(i+1)%4;setL(LN[i],C[i],C[j],.16+.1*Math.sin(t*1.3+i)+(hv[i]+hv[j])*.3);setL(LN[4+i],[cx,cy],C[i],.2+.1*Math.sin(t*1.1+i*2)+hv[i]*.6)}
PT.forEach(q=>{q.u+=.004+hv[q.k]*.02;if(q.u>1)q.u=0;const a=C[q.k];q.c.setAttribute('cx',cx+(a[0]-cx)*q.u);q.c.setAttribute('cy',cy+(a[1]-cy)*q.u);q.c.setAttribute('opacity',(.25+hv[q.k]*.75)*Math.sin(q.u*3.14))})}
// ---- layout / pinning ----
const sv=$('#services'),sg=$('#sg'),pr=$('#process'),pf=$('#pf'),pss=$$('.ps'),spi=$('#spi'),ab=$('#about'),ct=$('#contact'),ft=$('.foot'),m1=$('#m1'),m2=$('#m2');
const A=[...$$('#ah .al')],wl=[...$('#wm').children],h2c=$('.cta h2'),cg=$('.cg');
let L={},DIST=0,pinOn=false;const g=e=>{const r=e.getBoundingClientRect();return{t:r.top+scrollY,h:r.height}};
function layout(){pinOn=innerWidth>860&&!RM;sv.classList.toggle('pn',pinOn);pr.classList.toggle('pn',pinOn);sg.style.transform='';
if(pinOn){DIST=Math.max(0,sg.scrollWidth-innerWidth);sv.style.setProperty('--sh',V()+DIST+'px');pr.style.setProperty('--ph',V()*4.4+'px')}
L={sv:g(sv),pr:g(pr),ab:g(ab),ct:g(ct),ft:g(ft)};calc()}
addEventListener('resize',layout);addEventListener('load',layout);document.fonts&&document.fonts.ready.then(layout);layout();
// ---- smooth scroll ----
if(FINE&&!RM){let cur=scrollY,tg=scrollY,own=0;const mxs=()=>document.documentElement.scrollHeight-innerHeight;
addEventListener('wheel',e=>{if(e.ctrlKey||document.body.style.overflow=='hidden')return;e.preventDefault();tg=clamp(tg+e.deltaY*(e.deltaMode?30:1),0,mxs())},{passive:false});
addEventListener('scroll',()=>{if(!own&&Math.abs(scrollY-cur)>3)cur=tg=scrollY});
document.addEventListener('click',e=>{const a=e.target.closest('a[href^="#"]');if(!a||a.getAttribute('href')=='#')return;const el=$(a.getAttribute('href'));if(el){e.preventDefault();tg=clamp(el.getBoundingClientRect().top+scrollY,0,mxs())}});
(function f(){const d=tg-cur;if(Math.abs(d)>.3){own=1;cur+=d*.085;scrollTo(0,cur);setTimeout(()=>own=0,30)}requestAnimationFrame(f)})()}
// ---- main frame loop ----
let ly=scrollY,vl=0,dr=1,x1=0,x2=0,vx=0,hov1=0,T0=performance.now();
$('#m1').parentElement.addEventListener('mouseenter',()=>hov1=1);$('#m1').parentElement.addEventListener('mouseleave',()=>hov1=0);
(function frame(now){const sy=scrollY,v=V(),t=(now-T0)/1000;
vl+=((sy-ly)-vl)*.1;ly=sy;window.__v=Math.min(Math.abs(vl)*.12,6);if(Math.abs(vl)>.4)dr=vl>0?1:-1;
nav.classList.toggle('sm',dr>0&&sy>200);
if(!RM){mx+=(tmx-mx)*.06;my+=(tmy-my)*.06;
if(sy<v*1.4){const p=clamp(sy/(v*.95));
hg.style.opacity=1-p*.9;ht.style.translate=`0 ${-p*140}px`;vis.style.rotate=p*9+'deg';vis.style.scale=1+p*.28;c1.style.scale=`${1+p*.45} 1`;
[[60,40],[-40,-30],[50,30],[-90,-60]].forEach((k,i)=>{gs[i].style.translate=`${-mx*k[0]}px ${-my*k[1]-p*80*(i+1)*.3}px`});gs[0].style.scale=1+p*.7;
orbit(t,p)}
fgl.style.transform=`translate(${Math.sin(sy/900)*28}vw,${Math.cos(sy/1400)*14}vh)`;
const ap=clamp((sy+v-L.ab.t)/(v+L.ab.h*.6));A[0].style.translate=`${-(1-clamp(ap*2.2))*120}px 0`;A[0].style.opacity=clamp(ap*3);A[1].style.translate=`${(1-clamp(ap*1.8))*innerWidth*.7}px 0`;A[2].style.clipPath=`inset(0 ${(1-clamp((ap-.35)*3))*100}% 0 0 )`;
const cp=clamp((sy+v-L.ct.t)/(v*1.1));h2c.style.scale=.8+.2*cp;cg.style.scale=.6+.5*cp;
cds.forEach((d,i)=>{const a=i*.35+t*.15,r=50+(1-cp)*480+Math.sin(t+i)*10;d.style.transform=`translate(${Math.cos(a)*r*1.4}px,${Math.sin(a)*r*.7}px)`;d.style.opacity=.3+cp*.7});
const fp=clamp((sy+v-L.ft.t)/(L.ft.h+40));wl.forEach((l,i)=>l.style.transform=`translateX(${(1.5-i)*(1-fp)*.9}em)`);
vx+=.3+window.__v*1.4;const w=vw.scrollWidth/2;vw.style.transform=`translateX(${-(vx%w)}px)`;
x1+=(.6+window.__v*.9)*dr*(hov1?.25:1);const w1=m1.scrollWidth/2;x1=((x1%w1)+w1)%w1;m1.style.transform=`translateX(${-x1}px)`}
if(pinOn){const p=clamp((sy-L.sv.t)/(L.sv.h-v));sg.style.transform=`translate3d(${-p*DIST}px,0,0)`;spi.style.transform=`scaleX(${p})`;
const q=clamp((sy-L.pr.t)/(L.pr.h-v)),c=Math.min(5,Math.floor(q*6));pf.style.width=q*100+'%';pss.forEach((s,i)=>{s.classList.toggle('on',i<=c);s.classList.toggle('cur',i==c)})}
requestAnimationFrame(frame)})(T0);
// ---- hero canvas ----
(function(){const cv=$('#pt'),x=cv.getContext('2d');if(RM)return;let W,H,run=1;const N=MOB?22:50,P=[];
const rz=()=>{W=cv.width=cv.offsetWidth;H=cv.height=cv.offsetHeight};rz();addEventListener('resize',rz);
for(let i=0;i<N;i++)P.push({x:Math.random(),y:Math.random(),r:Math.random()*1.4+.5,vx:(Math.random()-.5)*.00012,vy:-Math.random()*.00014-.00004,g:Math.random()<.3,z:Math.random()*.8+.2});
new IntersectionObserver(e=>run=e[0].isIntersecting).observe(cv);
(function f(){if(run){x.clearRect(0,0,W,H);const a=window.__mx||0,b=window.__my||0;
P.forEach(p=>{p.x+=p.vx;p.y+=p.vy;if(p.y<0)p.y=1;if(p.x<0)p.x=1;if(p.x>1)p.x=0;p.px=p.x*W-a*40*p.z;p.py=p.y*H-b*26*p.z});
for(let i=0;i<N;i++){const A=P[i];for(let j=i+1;j<N;j++){const B=P[j],d=Math.hypot(A.px-B.px,A.py-B.py);if(d<130){x.strokeStyle=`rgba(214,168,95,${.16*(1-d/130)})`;x.beginPath();x.moveTo(A.px,A.py);x.lineTo(B.px,B.py);x.stroke()}}
x.beginPath();x.arc(A.px,A.py,A.r,0,7);x.fillStyle=A.g?'rgba(214,168,95,.7)':'rgba(245,241,243,.35)';x.fill()}}requestAnimationFrame(f)})()})();
// ---- stat/hero counters + loader ----
const cnt=(el,to,pre,suf,dec,dl)=>setTimeout(()=>{const s=performance.now();(function k(t){const p=clamp((t-s)/2200);el.textContent=pre+(to*(1-Math.pow(1-p,3))).toFixed(dec)+suf;if(p<1)requestAnimationFrame(k)})(s)},dl);
const ld=$('#ld'),lp=$('#lp'),L0=performance.now();document.body.style.overflow='hidden';
(function f(t){const p=clamp((t-L0)/(RM?100:1900)),e=1-Math.pow(1-p,3);lp.textContent=String(Math.round(e*100)).padStart(2,'0')+'%';
if(p<1)requestAnimationFrame(f);else{ld.classList.add('o');document.body.classList.add('ready');document.body.style.overflow='';setTimeout(()=>ld.remove(),1500);
cnt($('#gn'),210,'+','%',0,2400);cnt($('#g2n'),64,'','%',0,2700);cnt($('#g3n'),3.5,'','×',1,3000);layout()}})(L0);
})();

})();
window.addEventListener('load',function(){setTimeout(function(){var l=document.getElementById('ld');if(l){l.remove();document.body.classList.add('ready');document.body.style.overflow='';}},6000);});
