<?php // Required by WordPress. Fallback for posts/archives/404; the homepage is front-page.php.
get_header();aurele_hero('',is_home()?get_bloginfo('name'):(is_404()?'Page not found':wp_strip_all_tags(get_the_archive_title())));?>
<section class="pg"><div class="wrap"><div class="entry"><?php if(have_posts()){while(have_posts()){the_post();echo '<h3><a href="'.esc_url(get_permalink()).'">'.esc_html(get_the_title()).'</a></h3>';the_excerpt();}}else echo '<p class="t">Nothing found here.</p>';?></div></div></section>
<?php get_footer();
